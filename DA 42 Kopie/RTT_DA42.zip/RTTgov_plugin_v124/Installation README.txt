

The Plugin v1.24 ist testet for X-Plane 8.60

After unzipping, you have to unpack the Mac or Linux file seperately again.
Just drop the plugin that suits your operating system (Windows, Mac or Linux)

	into:

	...\X-Plane 8.60\Resources\plugins\

	And ready!


All user input in the sim is done with only one key (default F4) you can change it
permanently in the RTTgov preferences window from the X-Plane menu "Plug-Ins"

The key is used for the following planes:

	GliderXM (retracts engine)
	Me262 C-2b (on/off HWK engines)
	Horten IX HWK (on/off HWK engine)
	A750VG (parse external cameras)
	DA42 TwinStar (parse external cameras)

Everything else goes automatically.

Every reported bug will be solved usually within a few days.

Please report bugs in the members section of www.RTTdesign.eu


Known Bugs: None