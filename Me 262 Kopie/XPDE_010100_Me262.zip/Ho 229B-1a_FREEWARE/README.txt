
Horten Ho 229
X-Plane ACF model by Uwe F. Reitter


Only for Windows operable.

As:
Fighter typical fuel loads, choice of engine type, enemy detection in gunsight,
optional fully imperial display of flightparameter and some other functions.